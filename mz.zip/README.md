<h1 align="center"> |RANA MZ|</h1>
<h2 align="center"> ZESHi </h2>
<p align="center">
      A new international facebook account cracker tool for termux users
</p>






## <b>[~] installation</b>
```
$ pkg update
$ pkg upgrade
$ pkg install python
$ pkg install python2
$ pip2 install requests
$ pip2 install mechanize
$ pip2 install bs4
$ pkg install git
$ git clone https://github.com/RanaMZ/z3-hi.git
$ cd z3-hi
$ python2 mz.py
```

## [~] Single Command

```
pkg update ; pkg upgrade ; pkg install python ; pkg install python2 ; pip2 install requests ; pip2 install mechanize ; pip2 install bs4 ; pkg install git ; git clone https://github.com/RanaMZ/z3-hi.git  ; cd z3-hi ; python2 mz.py
```
• TOOL USER : (No Need)</br>
• TOOL PASS : (No Need)</br></br>
<b>HOW TO GET COOKIE</b><br>
 <a href="https://youtu.be/1vDsjuFqrWQ">  VIDEO TUTORIAL</a>
</br>
## <b>📱 Social Media 📱</b></br> <br> [![Facebook](https://img.shields.io/badge/Facebook-AZIM-blue?style=flat-square&logo=facebook)](https://www.facebook.com/RanaMZ007/)<br>[![Messenger](https://img.shields.io/badge/Messenger-Mr--Error-purple?style=flat-square&logo=messenger)](https://www.facebook.com/RanaMZ007/)<br> [![Github](https://img.shields.io/badge/Github-AZIM--MAHMUD-deepgreen?style=flat-square&logo=github)](https://github.com/RanaMZ/z3-hi.git)<br> [![Instagram](https://img.shields.io/badge/Instagram-AZIM--MAHMUD-hotpink?style=flat-square&logo=instagram)](MN NHI BTAON GA)


